﻿namespace Load_Estimator_by_AR
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Credit_button = new System.Windows.Forms.Button();
            this.Calculate_button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TypeList = new System.Windows.Forms.ComboBox();
            this.TotalArea = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.LightArea = new System.Windows.Forms.TextBox();
            this.PowerArea = new System.Windows.Forms.TextBox();
            this.HVACArea = new System.Windows.Forms.TextBox();
            this.Lightcode = new System.Windows.Forms.TextBox();
            this.Powercode = new System.Windows.Forms.TextBox();
            this.HVACcode = new System.Windows.Forms.TextBox();
            this.TotalLight = new System.Windows.Forms.TextBox();
            this.TotalPower = new System.Windows.Forms.TextBox();
            this.TotalHVAC = new System.Windows.Forms.TextBox();
            this.Lrange = new System.Windows.Forms.Label();
            this.Prange = new System.Windows.Forms.Label();
            this.HVACrange = new System.Windows.Forms.Label();
            this.Elevators = new System.Windows.Forms.Label();
            this.Water_PUMP = new System.Windows.Forms.Label();
            this.Fire_PUMPS = new System.Windows.Forms.Label();
            this.Equipment = new System.Windows.Forms.Label();
            this.Others = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.TotalOther = new System.Windows.Forms.TextBox();
            this.totalelevators = new System.Windows.Forms.TextBox();
            this.totalwater = new System.Windows.Forms.TextBox();
            this.totalfire = new System.Windows.Forms.TextBox();
            this.totalequipment = new System.Windows.Forms.TextBox();
            this.totalotherss = new System.Windows.Forms.TextBox();
            this.Total = new System.Windows.Forms.Label();
            this.TotalLoads = new System.Windows.Forms.TextBox();
            this.KVA = new System.Windows.Forms.Label();
            this.Export_button = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.info = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Credit_button
            // 
            resources.ApplyResources(this.Credit_button, "Credit_button");
            this.Credit_button.Name = "Credit_button";
            this.Credit_button.UseVisualStyleBackColor = true;
            this.Credit_button.Click += new System.EventHandler(this.button1_Click);
            // 
            // Calculate_button
            // 
            resources.ApplyResources(this.Calculate_button, "Calculate_button");
            this.Calculate_button.Name = "Calculate_button";
            this.Calculate_button.UseVisualStyleBackColor = true;
            this.Calculate_button.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // TypeList
            // 
            this.TypeList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TypeList.FormattingEnabled = true;
            this.TypeList.Items.AddRange(new object[] {
            resources.GetString("TypeList.Items"),
            resources.GetString("TypeList.Items1"),
            resources.GetString("TypeList.Items2"),
            resources.GetString("TypeList.Items3"),
            resources.GetString("TypeList.Items4"),
            resources.GetString("TypeList.Items5"),
            resources.GetString("TypeList.Items6"),
            resources.GetString("TypeList.Items7"),
            resources.GetString("TypeList.Items8"),
            resources.GetString("TypeList.Items9"),
            resources.GetString("TypeList.Items10"),
            resources.GetString("TypeList.Items11"),
            resources.GetString("TypeList.Items12"),
            resources.GetString("TypeList.Items13"),
            resources.GetString("TypeList.Items14")});
            resources.ApplyResources(this.TypeList, "TypeList");
            this.TypeList.Name = "TypeList";
            this.TypeList.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // TotalArea
            // 
            resources.ApplyResources(this.TotalArea, "TotalArea");
            this.TotalArea.Name = "TotalArea";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // LightArea
            // 
            this.LightArea.AutoCompleteCustomSource.AddRange(new string[] {
            resources.GetString("LightArea.AutoCompleteCustomSource")});
            resources.ApplyResources(this.LightArea, "LightArea");
            this.LightArea.Name = "LightArea";
            this.LightArea.TextChanged += new System.EventHandler(this.LightArea_TextChanged);
            // 
            // PowerArea
            // 
            resources.ApplyResources(this.PowerArea, "PowerArea");
            this.PowerArea.Name = "PowerArea";
            this.PowerArea.TextChanged += new System.EventHandler(this.PowerArea_TextChanged);
            // 
            // HVACArea
            // 
            resources.ApplyResources(this.HVACArea, "HVACArea");
            this.HVACArea.Name = "HVACArea";
            this.HVACArea.TextChanged += new System.EventHandler(this.HVACArea_TextChanged);
            // 
            // Lightcode
            // 
            resources.ApplyResources(this.Lightcode, "Lightcode");
            this.Lightcode.Name = "Lightcode";
            this.Lightcode.TextChanged += new System.EventHandler(this.Lightcode_TextChanged);
            // 
            // Powercode
            // 
            resources.ApplyResources(this.Powercode, "Powercode");
            this.Powercode.Name = "Powercode";
            this.Powercode.TextChanged += new System.EventHandler(this.Powercode_TextChanged);
            // 
            // HVACcode
            // 
            resources.ApplyResources(this.HVACcode, "HVACcode");
            this.HVACcode.Name = "HVACcode";
            this.HVACcode.TextChanged += new System.EventHandler(this.HVACcode_TextChanged);
            // 
            // TotalLight
            // 
            resources.ApplyResources(this.TotalLight, "TotalLight");
            this.TotalLight.Name = "TotalLight";
            this.TotalLight.ReadOnly = true;
            this.TotalLight.TextChanged += new System.EventHandler(this.TotalLight_TextChanged);
            // 
            // TotalPower
            // 
            resources.ApplyResources(this.TotalPower, "TotalPower");
            this.TotalPower.Name = "TotalPower";
            this.TotalPower.ReadOnly = true;
            // 
            // TotalHVAC
            // 
            resources.ApplyResources(this.TotalHVAC, "TotalHVAC");
            this.TotalHVAC.Name = "TotalHVAC";
            this.TotalHVAC.ReadOnly = true;
            this.TotalHVAC.TextChanged += new System.EventHandler(this.TotalHVAC_TextChanged);
            // 
            // Lrange
            // 
            resources.ApplyResources(this.Lrange, "Lrange");
            this.Lrange.Name = "Lrange";
            // 
            // Prange
            // 
            resources.ApplyResources(this.Prange, "Prange");
            this.Prange.Name = "Prange";
            this.Prange.Click += new System.EventHandler(this.label9_Click);
            // 
            // HVACrange
            // 
            resources.ApplyResources(this.HVACrange, "HVACrange");
            this.HVACrange.Name = "HVACrange";
            // 
            // Elevators
            // 
            resources.ApplyResources(this.Elevators, "Elevators");
            this.Elevators.Name = "Elevators";
            // 
            // Water_PUMP
            // 
            resources.ApplyResources(this.Water_PUMP, "Water_PUMP");
            this.Water_PUMP.Name = "Water_PUMP";
            // 
            // Fire_PUMPS
            // 
            resources.ApplyResources(this.Fire_PUMPS, "Fire_PUMPS");
            this.Fire_PUMPS.Name = "Fire_PUMPS";
            // 
            // Equipment
            // 
            resources.ApplyResources(this.Equipment, "Equipment");
            this.Equipment.Name = "Equipment";
            // 
            // Others
            // 
            resources.ApplyResources(this.Others, "Others");
            this.Others.Name = "Others";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // TotalOther
            // 
            resources.ApplyResources(this.TotalOther, "TotalOther");
            this.TotalOther.Name = "TotalOther";
            this.TotalOther.ReadOnly = true;
            // 
            // totalelevators
            // 
            resources.ApplyResources(this.totalelevators, "totalelevators");
            this.totalelevators.Name = "totalelevators";
            this.totalelevators.TextChanged += new System.EventHandler(this.totalelevators_TextChanged);
            // 
            // totalwater
            // 
            resources.ApplyResources(this.totalwater, "totalwater");
            this.totalwater.Name = "totalwater";
            this.totalwater.TextChanged += new System.EventHandler(this.totalwater_TextChanged);
            // 
            // totalfire
            // 
            resources.ApplyResources(this.totalfire, "totalfire");
            this.totalfire.Name = "totalfire";
            this.totalfire.TextChanged += new System.EventHandler(this.totalfire_TextChanged);
            // 
            // totalequipment
            // 
            resources.ApplyResources(this.totalequipment, "totalequipment");
            this.totalequipment.Name = "totalequipment";
            this.totalequipment.TextChanged += new System.EventHandler(this.totalequipment_TextChanged);
            // 
            // totalotherss
            // 
            resources.ApplyResources(this.totalotherss, "totalotherss");
            this.totalotherss.Name = "totalotherss";
            this.totalotherss.TextChanged += new System.EventHandler(this.totalotherss_TextChanged);
            // 
            // Total
            // 
            resources.ApplyResources(this.Total, "Total");
            this.Total.Name = "Total";
            // 
            // TotalLoads
            // 
            resources.ApplyResources(this.TotalLoads, "TotalLoads");
            this.TotalLoads.Name = "TotalLoads";
            this.TotalLoads.ReadOnly = true;
            // 
            // KVA
            // 
            resources.ApplyResources(this.KVA, "KVA");
            this.KVA.Name = "KVA";
            // 
            // Export_button
            // 
            resources.ApplyResources(this.Export_button, "Export_button");
            this.Export_button.Name = "Export_button";
            this.Export_button.UseVisualStyleBackColor = true;
            this.Export_button.Click += new System.EventHandler(this.Export_button_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // info
            // 
            resources.ApplyResources(this.info, "info");
            this.info.Name = "info";
            this.info.UseVisualStyleBackColor = true;
            this.info.Click += new System.EventHandler(this.info_Click);
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Controls.Add(this.info);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Export_button);
            this.Controls.Add(this.KVA);
            this.Controls.Add(this.TotalLoads);
            this.Controls.Add(this.Total);
            this.Controls.Add(this.totalotherss);
            this.Controls.Add(this.totalequipment);
            this.Controls.Add(this.totalfire);
            this.Controls.Add(this.totalwater);
            this.Controls.Add(this.totalelevators);
            this.Controls.Add(this.TotalOther);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.Others);
            this.Controls.Add(this.Equipment);
            this.Controls.Add(this.Fire_PUMPS);
            this.Controls.Add(this.Water_PUMP);
            this.Controls.Add(this.Elevators);
            this.Controls.Add(this.HVACrange);
            this.Controls.Add(this.Prange);
            this.Controls.Add(this.Lrange);
            this.Controls.Add(this.TotalHVAC);
            this.Controls.Add(this.TotalPower);
            this.Controls.Add(this.TotalLight);
            this.Controls.Add(this.HVACcode);
            this.Controls.Add(this.Powercode);
            this.Controls.Add(this.Lightcode);
            this.Controls.Add(this.HVACArea);
            this.Controls.Add(this.PowerArea);
            this.Controls.Add(this.LightArea);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.TotalArea);
            this.Controls.Add(this.TypeList);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Calculate_button);
            this.Controls.Add(this.Credit_button);
            this.DoubleBuffered = true;
            this.KeyPreview = true;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Credit_button;
        private System.Windows.Forms.Button Calculate_button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox TypeList;
        private System.Windows.Forms.Label TotalArea;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox LightArea;
        private System.Windows.Forms.TextBox PowerArea;
        private System.Windows.Forms.TextBox HVACArea;
        private System.Windows.Forms.TextBox Lightcode;
        private System.Windows.Forms.TextBox Powercode;
        private System.Windows.Forms.TextBox HVACcode;
        private System.Windows.Forms.TextBox TotalPower;
        private System.Windows.Forms.TextBox TotalHVAC;
        private System.Windows.Forms.Label Lrange;
        private System.Windows.Forms.Label Prange;
        private System.Windows.Forms.Label HVACrange;
        private System.Windows.Forms.Label Elevators;
        private System.Windows.Forms.Label Water_PUMP;
        private System.Windows.Forms.Label Fire_PUMPS;
        private System.Windows.Forms.Label Equipment;
        private System.Windows.Forms.Label Others;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox TotalOther;
        private System.Windows.Forms.TextBox totalelevators;
        private System.Windows.Forms.TextBox totalwater;
        private System.Windows.Forms.TextBox totalfire;
        private System.Windows.Forms.TextBox totalequipment;
        private System.Windows.Forms.TextBox totalotherss;
        private System.Windows.Forms.Label Total;
        private System.Windows.Forms.TextBox TotalLoads;
        private System.Windows.Forms.Label KVA;
        private System.Windows.Forms.Button Export_button;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox TotalLight;
        private System.Windows.Forms.Button info;

    }
}


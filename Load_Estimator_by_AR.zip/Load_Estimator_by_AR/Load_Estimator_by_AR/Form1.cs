﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Load_Estimator_by_AR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // Varaiable Intialization 
            LightArea.Text = ("0");
            PowerArea.Text = ("0");
            HVACArea.Text = ("0");
            Lightcode.Text = ("0");
            Powercode.Text = ("0");
            HVACcode.Text = ("0");
            totalelevators.Text = ("0");
            totalwater.Text = ("0");
            totalfire.Text = ("0"); ;
            totalequipment.Text = ("0");
            totalotherss.Text = ("0");

        }

        /// Credit Button Function

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Application developed by Aly Reda (AR)");
        }
        /// Info Button Function
        private void info_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Application use NEC Code for Load Estimation");
        }
        /// Application Print Result Functions

        private void button1_Click_1(object sender, EventArgs e)
        {
            LightCalculation_Range_Check();
            Power_Calculation_Range_Check();
            HVAC_Calculation_Range_Check();
            Others_Calculation();
            Total_Loads();
        
        }

        /// NEC Code DETAILS Function

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            string type = TypeList.Text;
            if (type == "Banks")
            {
                Lrange.Text = "20 : 40";
                Prange.Text = "30";
                HVACrange.Text = "50 : 70";
            }
            else if (type == "Cafeteria")
            {
                Lrange.Text = "25 : 45";
                Prange.Text = "5";
                HVACrange.Text = "60 : 100";
            }
            else if (type == "Computer Center")
            {
                Lrange.Text = "15 : 25";
                Prange.Text = "15";
                HVACrange.Text = "120 : 200";
            }
            else if (type == "Basement Stores")
            {
                Lrange.Text = "30 : 50";
                Prange.Text = "15";
                HVACrange.Text = "N/A";
            }
            else if (type == "Garages")
            {
                Lrange.Text = "5";
                Prange.Text = "1.5";
                HVACrange.Text = "N/A";
            }
            else if (type == "Hospital")
            {
                Lrange.Text = "20 : 30";
                Prange.Text = "10";
                HVACrange.Text = "50 : 70";
            }
            else if (type == "Hotels")
            {
                Lrange.Text = "10 : 30";
                Prange.Text = "5";
                HVACrange.Text = "50 : 80";
            }
            else if (type == "Office")
            {
                Lrange.Text = "15 : 35";
                Prange.Text = "15";
                HVACrange.Text = "110 : 120";
            }
            else if (type == "Library")
            {
                Lrange.Text = "15 : 35";
                Prange.Text = "5";
                HVACrange.Text = "100 : 120";
            }
            else if (type == "Restaurants")
            {
                Lrange.Text = "15 : 25";
                Prange.Text = "2.5";
                HVACrange.Text = "60 : 100";
            }
            else if (type == "Schools")
            {
                Lrange.Text = "15 : 35";
                Prange.Text = "15";
                HVACrange.Text = "35 : 50";
            }
            else if (type == "Theaters")
            {
                Lrange.Text = "20 : 30";
                Prange.Text = "10";
                HVACrange.Text = "700 : 1000";
            }
            else if (type == "Shopes")
            {
                Lrange.Text = "30 : 50";
                Prange.Text = "10";
                HVACrange.Text = "50 : 90";
            }
            else if (type == "Industrial Building")
            {
                Lrange.Text = "10 : 20";
                Prange.Text = "10";
                HVACrange.Text = "N/A";
            }
            else 
            {
                Lrange.Text = TypeList.Text;
                Prange.Text = TypeList.Text;
                HVACrange.Text = TypeList.Text;
            }
           
        }
        
        /// User Input Validation Functions

        private void Lightcode_TextChanged(object sender, EventArgs e)
        {
            float Lcode;
            if (float.TryParse(Lightcode.Text, out Lcode))
            {

            }
            else
            {
                MessageBox.Show("ERROR : Please Enter Numbers Only ");
            }
     
        }

        private void LightArea_TextChanged(object sender, EventArgs e)
        {
            float Larea;
            if (float.TryParse(LightArea.Text, out Larea))
            {
                Larea = float.Parse(LightArea.Text);
            }
            else
            {
                MessageBox.Show("ERROR : Please Enter Numbers Only ");
            }
        }
        private void PowerArea_TextChanged(object sender, EventArgs e)
        {
            float Parea;
            if (float.TryParse(PowerArea.Text, out Parea))
            {
                Parea = float.Parse(PowerArea.Text);
            }
            else
            {
                MessageBox.Show("ERROR : Please Enter Numbers Only ");
            }
        }

        private void Powercode_TextChanged(object sender, EventArgs e)
        {
            float Pcode;
            if (float.TryParse(Powercode.Text, out Pcode))
            {

            }
            else
            {
                MessageBox.Show("ERROR : Please Enter Numbers Only ");
            }

        }
        private void HVACArea_TextChanged(object sender, EventArgs e)
        {
            float HVACarea;
            if (float.TryParse(HVACArea.Text, out HVACarea))
            {
                HVACarea = float.Parse(HVACArea.Text);
            }
            else
            {
                MessageBox.Show("ERROR : Please Enter Numbers Only ");
            }
        }

        private void HVACcode_TextChanged(object sender, EventArgs e)
        {
            float HVACc;
            if (float.TryParse(HVACcode.Text, out HVACc))
            {

            }
            else
            {
                MessageBox.Show("ERROR : Please Enter Numbers Only ");
            }
        }
        private void totalelevators_TextChanged(object sender, EventArgs e)
        {
            float elevators;
            if (float.TryParse(totalelevators.Text, out elevators))
            {

            }
            else
            {
                MessageBox.Show("ERROR : Please Enter Numbers Only ");
            }
        }

        private void totalwater_TextChanged(object sender, EventArgs e)
        {
            float waterp;
            if (float.TryParse(totalwater.Text, out waterp))
            {

            }
            else
            {
                MessageBox.Show("ERROR : Please Enter Numbers Only ");
            }
        }

        private void totalfire_TextChanged(object sender, EventArgs e)
        {
            float firep;
            if (float.TryParse(totalfire.Text, out firep))
            {

            }
            else
            {
                MessageBox.Show("ERROR : Please Enter Numbers Only ");
            }
        }

        private void totalequipment_TextChanged(object sender, EventArgs e)
        {
            float equip;
            if (float.TryParse(totalequipment.Text, out equip))
            {

            }
            else
            {
                MessageBox.Show("ERROR : Please Enter Numbers Only ");
            }
        }

        private void totalotherss_TextChanged(object sender, EventArgs e)
        {
            float other;
            if (float.TryParse(totalotherss.Text, out other))
            {

            }
            else
            {
                MessageBox.Show("ERROR : Please Enter Numbers Only ");
            }
        }

        /// Calculation & Range Check Functions

        private float LightCalculation_Range_Check( )
        {
            // This Function used to Calculate and Range check for Lighning Loads
            float LRcheck;
            float Tlight = 0;
            if (float.TryParse(Lightcode.Text, out LRcheck))
            {
                string type = TypeList.Text;

                if (type == "Banks")
                {
                    if (LRcheck > 40 || LRcheck < 20 && LRcheck!=0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         Tlight = float.Parse(Lightcode.Text) * float.Parse(LightArea.Text);
                        TotalLight.Text = " " + Tlight;
                    }
                }
                else if (type == "Cafeteria")
                {
                    if (LRcheck > 45 || LRcheck < 25 && LRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         Tlight = float.Parse(Lightcode.Text) * float.Parse(LightArea.Text);
                        TotalLight.Text = " " + Tlight;
                    }
                }
                else if (type == "Computer Center")
                {
                    if (LRcheck > 25 || LRcheck < 15 && LRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         Tlight = float.Parse(Lightcode.Text) * float.Parse(LightArea.Text);
                        TotalLight.Text = " " + Tlight;
                    }
                }
                else if (type == "Basement Stores")
                {
                    if (LRcheck > 50 || LRcheck < 30 && LRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         Tlight = float.Parse(Lightcode.Text) * float.Parse(LightArea.Text);
                        TotalLight.Text = " " + Tlight;
                    }
                }
                else if (type == "Garages")
                {
                    if (LRcheck != 5 && LRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         Tlight = float.Parse(Lightcode.Text) * float.Parse(LightArea.Text);
                        TotalLight.Text = " " + Tlight;
                    }
                }
                else if (type == "Hospital")
                {
                    if (LRcheck > 30 || LRcheck < 20 && LRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         Tlight = float.Parse(Lightcode.Text) * float.Parse(LightArea.Text);
                        TotalLight.Text = " " + Tlight;
                    }
                }
                else if (type == "Hotels")
                {
                    if (LRcheck > 30 || LRcheck < 10 && LRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         Tlight = float.Parse(Lightcode.Text) * float.Parse(LightArea.Text);
                        TotalLight.Text = " " + Tlight;
                    }
                }
                else if (type == "Office")
                {
                    if (LRcheck > 35 || LRcheck < 15 && LRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         Tlight = float.Parse(Lightcode.Text) * float.Parse(LightArea.Text);
                        TotalLight.Text = " " + Tlight;
                    }
                }
                else if (type == "Library")
                {
                    if (LRcheck > 35 || LRcheck < 15 && LRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         Tlight = float.Parse(Lightcode.Text) * float.Parse(LightArea.Text);
                        TotalLight.Text = " " + Tlight;
                    }
                }
                else if (type == "Restaurants")
                {
                    if (LRcheck > 25 || LRcheck < 15 && LRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         Tlight = float.Parse(Lightcode.Text) * float.Parse(LightArea.Text);
                        TotalLight.Text = " " + Tlight;
                    }
                }
                else if (type == "Schools")
                {
                    if (LRcheck > 35 || LRcheck < 15 && LRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         Tlight = float.Parse(Lightcode.Text) * float.Parse(LightArea.Text);
                        TotalLight.Text = " " + Tlight;
                    }
                }
                else if (type == "Theaters")
                {
                    if (LRcheck > 30 || LRcheck < 20 && LRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         Tlight = float.Parse(Lightcode.Text) * float.Parse(LightArea.Text);
                        TotalLight.Text = " " + Tlight;
                    }
                }
                else if (type == "Shopes")
                {
                    if (LRcheck > 50 || LRcheck < 30 && LRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         Tlight = float.Parse(Lightcode.Text) * float.Parse(LightArea.Text);
                        TotalLight.Text = " " + Tlight;
                    }
                }
                else if (type == "Industrial Building")
                {
                    if (LRcheck > 20 || LRcheck < 10 && LRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         Tlight = float.Parse(Lightcode.Text) * float.Parse(LightArea.Text);
                        TotalLight.Text = " " + Tlight;
                    }
                }
                else
                {
                     Tlight = float.Parse(Lightcode.Text) * float.Parse(LightArea.Text);
                    TotalLight.Text = " " + Tlight;
                }

            }
            return Tlight;
        }


        private float Power_Calculation_Range_Check( )
        {
            // This Function used to Calculate and Range check for Power Loads
            float PRcheck;
            float TPower =0;
            if (float.TryParse(Powercode.Text, out PRcheck))
            {
                string type = TypeList.Text;
                if (type == "Banks")
                {
                    if (PRcheck != 30 && PRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         TPower = float.Parse(Powercode.Text) * float.Parse(PowerArea.Text);
                        TotalPower.Text = " " + TPower;
                    }
                }
                else if (type == "Cafeteria")
                {
                    if (PRcheck != 5 && PRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         TPower = float.Parse(Powercode.Text) * float.Parse(PowerArea.Text);
                        TotalPower.Text = " " + TPower;
                    }
                }
                else if (type == "Computer Center")
                {
                    if (PRcheck != 15 && PRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         TPower = float.Parse(Powercode.Text) * float.Parse(PowerArea.Text);
                        TotalPower.Text = " " + TPower;
                    }
                }
                else if (type == "Basement Stores")
                {
                    if (PRcheck != 15 && PRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         TPower = float.Parse(Powercode.Text) * float.Parse(PowerArea.Text);
                        TotalPower.Text = " " + TPower;
                    }
                }
                else if (type == "Garages")
                {
                    if (PRcheck != 1.5 && PRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         TPower = float.Parse(Powercode.Text) * float.Parse(PowerArea.Text);
                        TotalPower.Text = " " + TPower;
                    }
                }
                else if (type == "Hospital")
                {
                    if (PRcheck != 10 && PRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         TPower = float.Parse(Powercode.Text) * float.Parse(PowerArea.Text);
                        TotalPower.Text = " " + TPower;
                    }
                }
                else if (type == "Hotels" )
                {
                    if (PRcheck != 5 && PRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         TPower = float.Parse(Powercode.Text) * float.Parse(PowerArea.Text);
                        TotalPower.Text = " " + TPower;
                    }
                }
                else if (type == "Office")
                {
                    if (PRcheck != 15 && PRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         TPower = float.Parse(Powercode.Text) * float.Parse(PowerArea.Text);
                        TotalPower.Text = " " + TPower;
                    }
                }
                else if (type == "Library")
                {
                    if (PRcheck != 5 && PRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         TPower = float.Parse(Powercode.Text) * float.Parse(PowerArea.Text);
                        TotalPower.Text = " " + TPower;
                    }
                }
                else if (type == "Restaurants")
                {
                    if (PRcheck != 2.5 && PRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         TPower = float.Parse(Powercode.Text) * float.Parse(PowerArea.Text);
                        TotalPower.Text = " " + TPower;
                    }
                }
                else if (type == "Schools")
                {
                    if (PRcheck != 15 && PRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         TPower = float.Parse(Powercode.Text) * float.Parse(PowerArea.Text);
                        TotalPower.Text = " " + TPower;
                    }
                }
                else if (type == "Theaters")
                {
                    if (PRcheck != 10 && PRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         TPower = float.Parse(Powercode.Text) * float.Parse(PowerArea.Text);
                        TotalPower.Text = " " + TPower;
                    }
                }
                else if (type == "Shopes")
                {
                    if (PRcheck != 10 && PRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         TPower = float.Parse(Powercode.Text) * float.Parse(PowerArea.Text);
                        TotalPower.Text = " " + TPower;
                    }
                }
                else if (type == "Industrial Building")
                {
                    if (PRcheck != 10 && PRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         TPower = float.Parse(Powercode.Text) * float.Parse(PowerArea.Text);
                        TotalPower.Text = " " + TPower;
                    }
                }
                else
                {
                         TPower = float.Parse(Powercode.Text) * float.Parse(PowerArea.Text);
                         TotalPower.Text = " " + TPower;

                }
                
            }
            return TPower;
        }


        private float HVAC_Calculation_Range_Check()
        {
            // This Function used to Calculate and Range check for HVAC Loads
            float HVACRcheck;
            float THVAC =0;
            if (float.TryParse(HVACcode.Text, out HVACRcheck))
            {
                string type = TypeList.Text;
                if (type == "Banks")
                {
                    if (HVACRcheck > 70 || HVACRcheck < 50 && HVACRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         THVAC = float.Parse(HVACcode.Text) * float.Parse(HVACArea.Text);
                        TotalHVAC.Text = " " + THVAC;
                    }
                }
                else if (type == "Cafeteria")
                {
                    if (HVACRcheck > 100 || HVACRcheck < 60 && HVACRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         THVAC = float.Parse(HVACcode.Text) * float.Parse(HVACArea.Text);
                        TotalHVAC.Text = " " + THVAC;
                    }
                }
                else if (type == "Computer Center")
                {
                    if (HVACRcheck > 200 || HVACRcheck < 120 && HVACRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         THVAC = float.Parse(HVACcode.Text) * float.Parse(HVACArea.Text);
                        TotalHVAC.Text = " " + THVAC;
                    }
                }
                else if (type == "Basement Stores")
                {
                     THVAC = float.Parse(HVACcode.Text) * float.Parse(HVACArea.Text);
                    TotalHVAC.Text = " " + THVAC;
                }
                else if (type == "Garages")
                {
                     THVAC = float.Parse(HVACcode.Text) * float.Parse(HVACArea.Text);
                    TotalHVAC.Text = " " + THVAC;
                }
                else if (type == "Hospital")
                {
                    if (HVACRcheck > 70 || HVACRcheck < 50 && HVACRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         THVAC = float.Parse(HVACcode.Text) * float.Parse(HVACArea.Text);
                        TotalHVAC.Text = " " + THVAC;
                    }
                }
                else if (type == "Hotels")
                {
                    if (HVACRcheck > 80 || HVACRcheck < 50 && HVACRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         THVAC = float.Parse(HVACcode.Text) * float.Parse(HVACArea.Text);
                        TotalHVAC.Text = " " + THVAC;
                    }
                }
                else if (type == "Office")
                {
                    if (HVACRcheck > 120 || HVACRcheck < 110 && HVACRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         THVAC = float.Parse(HVACcode.Text) * float.Parse(HVACArea.Text);
                        TotalHVAC.Text = " " + THVAC;
                    }
                }
                else if (type == "Library")
                {
                    if (HVACRcheck > 120 || HVACRcheck < 100 && HVACRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         THVAC = float.Parse(HVACcode.Text) * float.Parse(HVACArea.Text);
                        TotalHVAC.Text = " " + THVAC;
                    }
                }
                else if (type == "Restaurants")
                {
                    if (HVACRcheck > 100 || HVACRcheck < 60 && HVACRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         THVAC = float.Parse(HVACcode.Text) * float.Parse(HVACArea.Text);
                        TotalHVAC.Text = " " + THVAC;
                    }
                }
                else if (type == "Schools")
                {
                    if (HVACRcheck > 50 || HVACRcheck < 35 && HVACRcheck != 0)
                    {
                        MessageBox.Show("ERROR : Please Enter Numbers within range ");
                    }
                    else
                    {
                         THVAC = float.Parse(HVACcode.Text) * float.Parse(HVACArea.Text);
                        TotalHVAC.Text = " " + THVAC;
                    }
                }
                else if (type == "Theaters")
                {
                     THVAC = float.Parse(HVACcode.Text) * float.Parse(HVACArea.Text);
                    TotalHVAC.Text = " " + THVAC;
                }
                else if (type == "Shopes")
                {
                     THVAC = float.Parse(HVACcode.Text) * float.Parse(HVACArea.Text);
                    TotalHVAC.Text = " " + THVAC;
                }
                else if (type == "Industrial Building")
                {
                     THVAC = float.Parse(HVACcode.Text) * float.Parse(HVACArea.Text);
                    TotalHVAC.Text = " " + THVAC;
                }
                else
                {
                     THVAC = float.Parse(HVACcode.Text) * float.Parse(HVACArea.Text);
                    TotalHVAC.Text = " " + THVAC;
                }

            }
            return THVAC;
        }

        private float Others_Calculation()
        {
            float Tother = float.Parse(totalelevators.Text) + float.Parse(totalwater.Text) + float.Parse(totalfire.Text) + float.Parse(totalequipment.Text) + float.Parse(totalotherss.Text);
            TotalOther.Text = " " + Tother;
            return Tother;
        }

        private void Total_Loads()
        {
            float TL = LightCalculation_Range_Check( );
            float TP = Power_Calculation_Range_Check();
            float THVAc = HVAC_Calculation_Range_Check();
            float TO = Others_Calculation() ;      
            float Total = TL + TP + THVAc + TO;
            TotalLoads.Text = " " + (Total/1000);
        }

        /// Export Function
        private void Export_button_Click(object sender, EventArgs e)
        {
            while (true)
            {
                SaveFileDialog Save = new SaveFileDialog();
                Save.Filter = "files (*.txt)|*.txt";
                Save.Title = "Save File";
                Save.FileName = "Untitled.txt" + ".txt";
                if (Save.ShowDialog() == DialogResult.OK)
                {
                    string strpath = Save.FileName;
                    if (Path.GetExtension(Save.FileName) != ".txt")
                    {
                        strpath += ".txt";
                    }
                    StreamWriter sw = new StreamWriter(strpath);
                    sw.WriteLine("                                                        Load Estimation");
                    sw.WriteLine("Building Type = " + TypeList.Text);
                    sw.WriteLine("                          Total Area in m2 " + "            VA/m2" + "               Total Estimated Load (VA)		");
                    sw.WriteLine("Lightning Loads                  " + LightArea.Text + "                     " + Lightcode.Text + "                        " + TotalLight.Text);
                    sw.WriteLine("Power Loads                      " + PowerArea.Text + "                     " + Powercode.Text + "                        " + TotalPower.Text);
                    sw.WriteLine("HVAC Loads                       " + HVACArea.Text + "                     " + HVACcode.Text + "                        " + TotalHVAC.Text);
                    sw.WriteLine("Other Loads                                                                       " + TotalOther.Text);
                    sw.WriteLine("                       Total Estimated Load (VA) ");
                    sw.WriteLine("Elevators                        " + totalelevators.Text);
                    sw.WriteLine("Water pumps                      " + totalwater.Text);
                    sw.WriteLine("Fire Pumps                       " + totalfire.Text);
                    sw.WriteLine("Equipment                        " + totalequipment.Text);
                    sw.WriteLine("Others                           " + totalotherss.Text);
                    sw.WriteLine("_______________________________________________________________________________________________________");
                    sw.WriteLine("Total Estimated Load For Building = " + TotalLoads.Text + "  KVA");
                    sw.Close();
                    break;
                }
            }
          
            
        }
       
        /// NULL FUNCTIONS 

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
        private void TotalLight_TextChanged(object sender, EventArgs e)
        {

        }
        private void TotalHVAC_TextChanged(object sender, EventArgs e)
        {

        }




    }
}
